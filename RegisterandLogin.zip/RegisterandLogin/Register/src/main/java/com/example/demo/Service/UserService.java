package com.example.demo.Service;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.example.demo.Repository.UerRepository;
import com.example.demo.User.User;

@Service
public class UserService {
	
	@Autowired
	private  UerRepository repo;

	@Autowired
	private PasswordEncoder encoder;
	
//	public void save(User user)
//	{
//		String password = user.getPassword();
//		String encodedPassword = encoder.encode(password);
//		user.setPassword(encodedPassword);
//		repo.save(user);
//	}
	
	public void save(User user)
	{
		String password = user.getEmail();
		String encodedPassword = encoder.encode(password);
		user.setEmail(encodedPassword);
		repo.save(user);
	}

	public String login(String username, String password ) {
		// TODO Auto-generated method stub
		User user=repo.findByUsernameAndPassword(username,password);
		
		if(user!=null)
			{
					String uname=user.getUsername();
					String upass=user.getPassword();
				
					if(username.equalsIgnoreCase(uname) && password.equalsIgnoreCase(upass)) 
					{
						
						return "dummy";
					}
					else 
					{
						
						return "login999";
					}
				}
			else
			{
					
					return "login1000";
				}
			}
		
		
		
		
		
	
		
	}



//	@Override
//	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//		// TODO Auto-generated method stub
//		User user = repo.findByUsername(username);
//        if (user == null) {
//            throw new UsernameNotFoundException(username);
//		
//	}
//		return null;
//	}

