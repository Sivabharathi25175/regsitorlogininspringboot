package com.example.demo.Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Repository.UerRepository;
import com.example.demo.Service.UserService;
import com.example.demo.User.User;

@RestController
public class UserController {
	
	@Autowired
	private UserService service;
	
	@Autowired
	private  UerRepository repo1;

	
	@PostMapping("/register")
	public String register(@RequestBody User user)
	{
		service.save(user);
		return "success";
	}
	
//	@GetMapping("/login") 
//	public String login(@RequestParam("username") String username, @RequestParam("password") String password ,HttpSession session,ModelMap modelMap)
//	{
//	
//		User user=repo1.findByUsernameAndPassword(username, password);
//		
//	 
//    	if(user!=null)
//	{
//			String uname=user.getUsername();
//			String upass=user.getPassword();
//		
//			if(username.equalsIgnoreCase(uname) && password.equalsIgnoreCase(upass)) 
//			{
//				session.setAttribute("username",username);
//				return "dummy";
//			}
//			else 
//			{
//				modelMap.put("error", "Invalid Account");
//				return "login999";
//			}
//		}
//	else
//	{
//			modelMap.put("error", "Invalid Account");
//			return "login1000";
//		}
//	}
}


