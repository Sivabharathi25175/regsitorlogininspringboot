package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.User.User;

@Repository
public interface UerRepository extends JpaRepository<User,Long>{

	User findByUsernameAndPassword(String username, String password);

	User findByUsername(String username);

//	User findByUsername(String username);

	

}
